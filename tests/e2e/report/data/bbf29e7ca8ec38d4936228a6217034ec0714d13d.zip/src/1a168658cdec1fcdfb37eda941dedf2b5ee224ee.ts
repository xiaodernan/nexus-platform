import { test, expect } from '../../lib/fixture.js';
import type { Page } from '@playwright/test';

/**
 * Vertical slice = the MVP acceptance path (spec §168, §170, §138, §141).
 * These tests are the definition of "MVP complete". A green run here is the only thing that counts.
 *
 * Locators ride the surface's own stable hooks, not markup details: cards are `article[data-card-type]`
 * (the attribute every card carries), the merchant page's sections are `aria-labelledby` targets, and the
 * degraded notice is the warning row inside the stage list. The first draft waited on `data-testid`
 * markers the rebuilt surface no longer prints (D328's census: nine names, twenty waits, zero on the
 * plane) — this rewrite is the route-contract remedy, and marker re-adding stays available to the
 * surface's owner without conflicting with it.
 */

/** Every card on any surface prints its type; the type is the hook. */
function cards(page: Page) {
  return page.locator('article[data-card-type]');
}

/** The price each card shows, in the order the consumer sees it. Cards with no price are
 *  skipped rather than guessed at, so a reader that wants an ordering must find priced cards. */
async function cardPrices(page: Page): Promise<number[]> {
  const text = await cards(page).allInnerTexts();
  return text
    .map((t) => /HK\$(\d+)/.exec(t)?.[1])
    .filter((v): v is string => v !== undefined)
    .map(Number);
}

/** The §105 degraded notice: the stage list's warning row, with the label the dict prints. */
function degradedNotice(page: Page) {
  return page.locator('ol li').filter({ hasText: /流式搜索失败|降级|degraded/i }).first();
}

test.describe('consumer core journey', () => {
  test('landing page explains the product in <30s and takes a natural-language ask', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
    const search = page.getByLabel(/想要|需要|Tell me|What are you looking for/i);
    await expect(search).toBeVisible();
    // §6: rails below the fold
    for (const rail of [/Popular near you|附近熱門/, /For You|為你推薦/, /Trending|趨勢/]) {
      await expect(page.getByText(rail).first()).toBeVisible();
    }
    // §109/§155: synthetic inventory must announce itself
    await expect(page.getByText(/DEMO|演示|Synthetic/i).first()).toBeVisible();
  });

  test('natural-language ask → understanding → ranked cards with verifiable explanations', async ({ page }) => {
    await page.goto('/');
    await page.getByLabel(/想要|需要|Tell me|What are you looking for/i).fill(
      '帮我找沙田适合情侣约会的餐厅，预算500港币，安静一点，周六晚上',
    );
    await page.keyboard.press('Enter');

    // §116: staged progress, no chain-of-thought leakage
    await expect(page.getByText(/理解|搜索|对比|找到|Understanding|Searching/i).first()).toBeVisible();
    await expect(page.getByText(/找到|Found/).first()).toBeVisible({ timeout: 20000 });

    const found = cards(page);
    await expect(found.first()).toBeVisible();
    expect(await found.count(), 'AI search returned no merchants').toBeGreaterThan(0);

    // §18: reasons are enumerable and each is grounded — the card renders its list
    await expect(found.first().locator('li').first()).toBeVisible();

    // §94 cold start: results must actually be near Sha Tin
    const distances = await found.evaluateAll((els) =>
      els.map((el) => el.textContent ?? ''),
    );
    expect(distances.join(' ')).toMatch(/m|km|分鐘|min/i);
  });

  test('cards never render an ungrounded number', async ({ page, ai }) => {
    const res = await ai.post('/ai/v1/search', {
      data: {
        intent: { raw_query: '日式料理', intent: 'discover_merchant', category: 'restaurant' },
        geo: { lat: 22.3809, lng: 114.1861 },
        limit: 20,
      },
    });
    expect(res.status(), await res.text()).toBe(200);
    const { items } = await res.json();
    expect(items?.length, 'deterministic search returned nothing — seed not loaded?').toBeGreaterThan(0);
    for (const item of items) {
      const facts = new Set((item.facts ?? []).map((f: { attribute: string }) => f.attribute));
      if (item.price?.amount != null) expect(facts.has('price'), `${item.slug} price has no fact`).toBe(true);
      if (item.rating?.value != null) expect(facts.has('rating'), `${item.slug} rating has no fact`).toBe(true);
      if (item.open?.is_open != null) expect(facts.has('opening_hours'), `${item.slug} hours has no fact`).toBe(true);
      expect(item.flags?.demo, `${item.slug} synthetic data not labelled`).toBe(true);
    }
  });

  test('conversation refinement keeps state (§34)', async ({ page }) => {
    await page.goto('/search?q=' + encodeURIComponent('帮我找附近适合朋友聚会的餐厅'));
    await expect(cards(page).first()).toBeVisible({ timeout: 20000 });

    await page.getByRole('button', { name: /太贵了| cheaper/i }).first().click();
    await expect(cards(page).first()).toBeVisible();
    // §34 through to §67: the refinement is not a re-render of the same answer, it is a
    // different order. The sort the user asked for has to be readable in the card list.
    const prices = await cardPrices(page);
    expect(prices.length, 'the cheaper turn answered with fewer than two priced cards').toBeGreaterThan(1);
    expect(prices, `太贵了 did not order the answer by price: ${prices.join(', ')}`).toEqual(
      [...prices].sort((a, b) => a - b),
    );
    await page.getByRole('button', { name: /近一点|closer/i }).first().click();
    // §8: a preference re-orders the answer; it must never empty it.
    await expect(cards(page).first()).toBeVisible();
  });

  test('compare three merchants from real rows only (§37)', async ({ page }) => {
    await page.goto('/search?q=' + encodeURIComponent('适合约会 餐厅'));
    await expect(cards(page).first()).toBeVisible({ timeout: 20000 });
    for (let i = 0; i < 3; i++) await cards(page).nth(i).locator('button[aria-pressed]').click();
    // Selecting the third card opens the tray; the comparison table is the cost surface (§37).
    await expect(page.locator('table')).toBeVisible();
    for (const row of [/Price|价格|人均/, /Rating|评分/, /Distance|距离/]) {
      await expect(page.locator('table').getByText(row).first()).toBeVisible();
    }
    // Each chip's remove control names its own card, so it can be addressed and it drops
    // exactly that card rather than whichever chip happens to be first.
    const tray = page.getByRole('region', { name: /对比|Compare/ });
    const chips = tray.locator('ul > li');
    await expect(chips).toHaveCount(3);
    const title = (await chips.first().locator('a').innerText()).trim();
    await chips.first().getByRole('button', { name: `从对比中移除 ${title}` }).click();
    await expect(chips).toHaveCount(2);
    await expect(chips.getByRole('link', { name: title })).toHaveCount(0);
  });

  test('merchant page: facts, hours, menu, reviews with evidence, action (§4, §54)', async ({ page }) => {
    await page.goto('/search?q=' + encodeURIComponent('餐厅'));
    const link = cards(page).first().getByRole('link');
    const href = await link.getAttribute('href');
    expect(href, 'the first result should link to a merchant profile').toMatch(/^\/m\/[^/]+$/);
    await link.click();
    // A client-side navigation keeps the previous page on screen until the profile's data
    // arrives, so every assertion below would otherwise read the search page (its own h1 and
    // status text satisfy them) and the reviews panel would time out as "missing".
    await expect(page).toHaveURL((url) => url.pathname === href, { timeout: 20000 });
    const reviews = page.locator('section[aria-labelledby="reviews-title"]');
    await expect(reviews).toBeVisible({ timeout: 20000 });
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
    await expect(page.getByText(/Open|营业|開館|營業/i).first()).toBeVisible();
    // §55: summary claims must trace back to review rows
    await expect(reviews.locator('li').first()).toBeVisible();
  });

  test('reservation → confirmation, with capacity actually consumed (§51)', async ({ page, ai }) => {
    test.skip(!process.env.NEXUS_E2E_WRITE_PATHS, 'mutating path requires a dedicated demo tenant');
    await page.goto('/search?q=' + encodeURIComponent('可以预订的餐厅 周六晚上'));
    await cards(page).first().getByRole('link').click();
    // The surface's own comment records that no Reserve button exists yet (§44 unwired); when the
    // booking UI lands, its slots need a hook this file can wait on.
    await page.locator('section[aria-labelledby="hours-title"]').waitFor({ state: 'visible' }).catch(() => {});
    await page.getByRole('button', { name: /预订|Reserve/i }).click();
    await expect(page.getByText(/NX-RES-/)).toBeVisible();
  });

  test('LLM outage degrades instead of breaking the site (§105)', async ({ page }) => {
    // A healthy stream: `done` is the only event that prints the run id, so waiting for it proves
    // the stream finished — and then the page must not claim it fell back to deterministic search.
    // The browser calls the BFF, never the AI service directly.
    await page.goto('/search?q=' + encodeURIComponent('附近咖啡馆'));
    await expect(cards(page).first()).toBeVisible({ timeout: 20000 });
    await expect(page.getByText(/运行编号|run [0-9a-f]{8}-/i).first()).toBeVisible({ timeout: 20000 });
    await expect(page.getByText(/流式搜索失败|Streaming failed/i)).toHaveCount(0);

    await page.route('**/api/nexus/ai/stream', (r) => r.abort('failed'));
    await page.goto('/search?q=' + encodeURIComponent('附近咖啡馆'));
    // deterministic search must still return cards, plus a visible fallback marker
    await expect(cards(page).first()).toBeVisible({ timeout: 15000 });
    await expect(degradedNotice(page)).toBeVisible();
    await expect(page.getByText(/运行编号|run [0-9a-f]{8}-/i)).toHaveCount(0);
  });

  test('MVP success test: first meaningful action inside 5 minutes (§141)', async ({ page }) => {
    const started = Date.now();
    await page.goto('/');
    await page.getByLabel(/想要|需要|Tell me/i).fill('帮我找一个周末情侣约会方案');
    await page.keyboard.press('Enter');
    await expect(cards(page).first()).toBeVisible({ timeout: 120000 });
    const elapsed = Date.now() - started;
    expect(elapsed, `took ${elapsed}ms to first recommendation`).toBeLessThan(120000);
  });
});
